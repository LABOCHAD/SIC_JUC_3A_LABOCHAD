package _20250221PasswordBuilder;

import java.util.Scanner;

public class Login {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        //TODO: get user input here!

        //TODO: ask the user to enter PW after successfully created the PW

        //TODO: use all methods created in PasswordBuilder, and print the result
    }
}
