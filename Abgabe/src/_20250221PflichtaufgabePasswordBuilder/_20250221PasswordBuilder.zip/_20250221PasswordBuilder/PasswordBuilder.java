package _20250221PasswordBuilder;

import java.util.Random;

public class PasswordBuilder {
    Random random = new Random();

    // Generated Password
    private StringBuilder password = new StringBuilder();

    // values for the Password
    private String firstNameAndLastNameWithSpace;
    private String favoriteAnimal;
    private int birthYear;


    // TODO: get user input for Values - every Value must be filled
    // write a constructor

    // TODO: write a method that returns a String with a generated Password from the information granted from the Values
    // first Letter of the Password must be upper Case
    // all other Letters must be lower Case
    // you should use 4 Chars from both Strings
    // no space (" ") in the PW allowed
    // the Password should be 11 Characters long
    // in the middle must be the last two numbers from the BirthYear
    // the last char of the Password should be a special Character (like: !@#$%^&* or other) that makes 11 total chars in the PW
    // the password is saved in the StringBuilder but the return to the main method is a String so the main method can Print the PW


    // TODO: test user input if PW is correct -> return a boolean

    // TODO: write a method to reverse the PW -> return a String

    // TODO: write a method to remove the last Character -> return a String

}

//help: use: .append(), .equals(), .insert(), .deleteCharAt(), .reverse()