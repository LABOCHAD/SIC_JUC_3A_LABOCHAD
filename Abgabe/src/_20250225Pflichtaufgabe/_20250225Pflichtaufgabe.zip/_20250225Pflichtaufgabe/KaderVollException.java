package _20250225Pflichtaufgabe;

public class KaderVollException {
    // Checked Exception
    //TODO erbe von Exception und erstelle einen Konstruktor für diese Klasse
}
