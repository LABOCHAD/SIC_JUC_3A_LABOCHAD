package _20250225Pflichtaufgabe;

public class Main {
    public static void main(String[] args) {
        Mannschaft team = new Mannschaft();

        try {
            team.spielerHinzufuegen(new Spieler("Thomas Müller", 25));
            team.spielerHinzufuegen(new Spieler("Manuel Neuer", 1));
            team.spielerHinzufuegen(new Spieler("Joshua Kimmich", 6));
            team.spielerHinzufuegen(new Spieler("Leroy Sané", 10));
            team.spielerHinzufuegen(new Spieler("Leon Goretzka", 8));
            team.spielerHinzufuegen(new Spieler("Serge Gnabry", 7));
            team.spielerHinzufuegen(new Spieler("Jamal Musiala", 42));
            team.spielerHinzufuegen(new Spieler("Antonio Rüdiger", 2));
            team.spielerHinzufuegen(new Spieler("Niklas Süle", 4));
            team.spielerHinzufuegen(new Spieler("David Raum", 3));
            team.spielerHinzufuegen(new Spieler("Marc-André ter Stegen", 22));
            // TODO: Füge weitere Spieler hinzu (maximal 11)
            // Teste auch, was passiert, wenn du einen 12. Spieler hinzufügst (sollte eine Exception auslösen)
        } catch (KaderVollException e) {
            System.out.println("Fehler: " + e.getMessage());
        }

        team.mannschaftAnzeigen();

        // TODO: Teste das Entfernen eines Spielers
        // Teste auch das Entfernen eines Spielers, der nicht existiert (sollte eine Unchecked Exception auslösen)
    }
}

