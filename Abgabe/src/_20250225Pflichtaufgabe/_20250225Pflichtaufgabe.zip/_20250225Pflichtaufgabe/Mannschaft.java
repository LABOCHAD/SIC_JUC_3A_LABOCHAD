package _20250225Pflichtaufgabe;

import java.util.ArrayList;

public class Mannschaft {
    private ArrayList<Spieler> spielerListe;
    private static final int MAX_SPIELER = 11;

    public Mannschaft() {
        this.spielerListe = new ArrayList<>();
    }

    // Spieler hinzufügen (Checked Exception, falls Team voll)
    public void spielerHinzufuegen(Spieler spieler) throws KaderVollException {
        // TODO: Prüfe, ob die maximale Anzahl erreicht wurde
        // Falls ja, werfe eine KaderVollException mit passender Fehlermeldung

        // TODO: Falls nicht, füge den Spieler zur Liste hinzu
    }

    // Spieler entfernen (Unchecked Exception, falls Spieler nicht existiert)
    public void spielerEntfernen(String name) {
        // TODO: Suche den Spieler nach Namen
        // Falls Spieler nicht existiert, werfe eine SpielerNichtGefundenException

        // TODO: Falls Spieler existiert, entferne ihn aus der Liste
    }

    // Mannschaft ausgeben
    public void mannschaftAnzeigen() {
        System.out.println("Aktuelle Mannschaft:");
        for (Spieler s : spielerListe) {
            System.out.println(s);
        }
    }
}
