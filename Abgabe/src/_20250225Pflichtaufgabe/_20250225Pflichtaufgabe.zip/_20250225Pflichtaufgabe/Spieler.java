package _20250225Pflichtaufgabe;

public class Spieler {
    private String name;
    private int rueckennummer;

    // TODO erstelle einen Konstruktor, welcher name und rueckennummer initialisiert

    // TODO erstelle getter für die Attribute

    // TODO überschreibe toString() und gebe z.B. "Spieler: Max Nr. 90" aus
}
