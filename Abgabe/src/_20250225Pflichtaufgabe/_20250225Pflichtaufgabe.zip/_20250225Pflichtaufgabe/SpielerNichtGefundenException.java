package _20250225Pflichtaufgabe;

public class SpielerNichtGefundenException {
    // Unchecked Exception
    //TODO erbe von RuntimeException und erstelle einen Konstruktor für diese Klasse
}
