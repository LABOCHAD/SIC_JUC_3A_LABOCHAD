// Main class to test casting
public class PaymentTest {
    public static void main(String[] args) {
        // TODO: Upcasting: Storing different payment types in a Payment Array or ArrayList
        // Sample payment types:
        // new CreditCardPayment(100, "1234-5678-9012-3456")
        // new PayPalPayment(200, "user@example.com")
        // new CryptoPayment(300, "0xAbC123456789")


        // TODO: Processing payments using upcasting
        // use an advanced for loop

            // Call overridden method from child class processPayment()

            // Downcasting: Checking type (with instanceof()) and calling specific methods


            System.out.println("------"); // divider -> end of for loop

    }
}
