public class DoNOTlookInside {
    private String wifiPW = "02947";
    private String pcPW = "MpilteWiT.TtfLaep,bcaNtUalC.AatitN42!";
    private String decryptedText = "My password is linked to every Word in this Text. Take the first Letter and every punctuation, be careful and Note the Upper and lower Case. After all there is the Number 42!";

    protected String getPcPW() {
        return pcPW;
    }
    protected String getWifiPW() {
        return wifiPW;
    }

    // YOU SHOULD NOT BE HERE!!!
}
