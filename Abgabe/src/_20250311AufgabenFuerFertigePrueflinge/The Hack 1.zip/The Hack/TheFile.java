public class TheFile {
    String[] contentToBeEncrypted = {
            "ZeroByte", "CipherX", "Ghost_Protocol", "ShadowRoot", "NullPointer",
            "Xploit", "BytePhantom", "DarkNetSpecter", "GlitchMatrix", "Overclock",
            "KernelPanic", "BugHunter", "Hexadecima", "404NotFound", "MalwareMind",
            "Decryptor", "PacketSniff3r", "DDoSMaster", "BruteForceX", "QuantumRoot"
    };
}
