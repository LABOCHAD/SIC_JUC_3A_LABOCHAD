import java.util.Scanner;

public class TheKitchen {
    public static void main(String[] args) {
        DoNotLookInside database = new DoNotLookInside();


        System.out.println("David fidgets in the kitchen, avoiding eye contact.\n" +
                        "\n" +
                        "\"Where were you at the time of the murder?\"\"In the kitchen, making coffee. \nI wasn’t anywhere near Mark. I mean, I saw him earlier, but...\"\n" +
                        "\n" +
                        "\"Did Mark suspect anyone of wrongdoing?\"\"Not that I know of. He kept his business affairs to himself.\"\n");


        System.out.println("\"A whiskey glass lies shattered on the floor. \nThe toxicology report confirms the poison was in the whiskey. \nWho touched the glass?\"");
        String[] guests = new String[] {"Sophia", "David", "Ghost", "Elizabeth"};
        //TODO: search in database for the fingerprints of the guests and see if you find a match

    }
}
//help: you need to iterate through the guests and compare it to the String[] database.evidenceKitchen
