import java.util.Random;

public class TheLounge {
    public static void main(String[] args) {
        DoNotLookInside usbStick = new DoNotLookInside(1);


        System.out.println("Elizabeth adjusts her glasses, calm but irritated.\n" +
                        "\n" +
                        "\"Where were you at the time of the murder?\"\"In the lounge, reading. I prefer solitude.\"\n" +
                        "\n" +
                        "\"What was your last conversation with Mark about?\"\"Books, naturally. He borrowed one and never returned it. \nHardly motive for murder, wouldn’t you say?\"");

        System.out.println("\"You find an USB-Stick contains a passcode encrypted message in her purse.");


        //TODO: use the use a brute force attack to crack the passcode to crack the USB-Stick
        // the passcode contains only numbers and is 5 digits long
        // the passcode can be compared using "usbStick.tryPasscode"

    }
}
//help: a brute force attack can be made with a simple Random generator which generates a random 5 digits long number
