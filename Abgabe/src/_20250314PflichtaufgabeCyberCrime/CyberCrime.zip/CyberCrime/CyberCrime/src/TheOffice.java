import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashMap;

public class TheOffice {
    public static void main(String[] args) {
        DoNotLookInside findlogs = new DoNotLookInside();

        System.out.println("You go to the next person\n" +
                "Axel \"Ghost\" Nakamura (The Hacker)\n" +
                "\n" +
                "Axel leans back in a chair in the basement, arms crossed.\n" +
                "\n" +
                "\"Where were you at the time of the murder?\"\"Down here. I was setting up a security test for Mark’s systems. \nWe had a deal—he’d pay me to try and break in. \nBut I didn’t touch his files. I swear.\"\n" +
                "\n" +
                "\"Did you notice anything unusual?\"\"Yeah. \nSomeone else logged in at 10:30 PM. Wasn’t me. Logs don’t lie.\"");


        System.out.println("\"Mark’s laptop is still open. \nThe last login entry shows activity at 10:30 PM. \nBut who accessed it?\"");

        //TODO: search in the logs "findlogs.logs" for the Date and time of the murder


        System.out.println("There is a Safe behind a Painting, I'll guess there is not the clue in it, because it was not opened at that killer evening, but maybe I will find some Information on why he was killed.");
    }
}
//help: the date and time is written in the start. just go through the hashmap of logs
//the function of a hashmap(like a list) you need is get(key), the key is the date and time, and it returns a Value(name of a suspect)