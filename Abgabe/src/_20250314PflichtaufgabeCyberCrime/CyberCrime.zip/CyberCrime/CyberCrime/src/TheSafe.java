public class TheSafe {
    public static void main(String[] args) {
        System.out.println("His friend Elizabeth said something about that he loved the the dual number system. \nI think if we can transform his birth year 1983 into the dual system");

        //TODO: optional
        //TODO: make 1983 a dual number
        // you can check your number with DoNotLookInside.safe();

    }
}

